<html>
<link rel="stylesheet" href="estilos.css" />

<body>
  <form method="GET" action="buscar.php">
    <strong>ciudad:</strong> 
    
    <input type="text" name="capitaln" size="20"><br><br>
    <input type="submit" value="buscar" name="buscar">
  </form>

  <?php


  $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
  $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');


  //$id = filter_input(INPUT_GET, 'id');
  //$capitaln = $_GET['capitaln']; 
  //$Id = $_GET['id'];
  $capitaln = filter_input(INPUT_GET, 'capitaln');
  //echo $capitaln;
  //echo  $id ;
if($capitaln){
  $query = "SELECT id from capital WHERE capitaln='$capitaln'";
  $result2 = mysqli_query($link, $query);
  $row_cnt = $result2->num_rows;
  
  if ($row_cnt>0) { 
      while ($row = mysqli_fetch_array($result2)) {
          echo "<tr>";
          echo "<td>" . $row['id'] . "</td>";
//          echo "<td>" . $row['capitaln'] . "</td>";
          echo "</tr>";
     }
    echo "<p>Registro encontrado.$capitaln.id</p>";
  } else {
    echo "<p>Registro NOOO encontrado</p>"; 
  }
}
else{
   echo "<p>Introduce una capital</p>"; 
}
  ?>