<html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="estilos.css" />
</head>
<body>
    <div class="datos">
        <h2>Base de datos actualizada</h2>
    
    <?php
    $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
    $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');

    //   $capitaln =$_POST['capitaln'];
    $sql = "SELECT * FROM usuario";
    $result = mysqli_query($link, $sql);
    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            echo "<table border='2'>";
            echo "<tr>";
            echo "<th>id</th>";
            echo "<th>Usuario</th>";
            echo "</tr>";
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>" . $row['idUsu'] . "</td>";
                echo "<td>" . $row['nombreUsuario'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
    ?>
    <?php



    ?>
    </div></body></html>