<html>

<head>
  <meta charset="UTF-8">
  <title></title>
  <link rel="stylesheet" href="estilos.css" />
</head>

<body>
  <div class="borrar">
    <h2>Indica el pais a borrar</h2>

    <form action="borrar.php" method="GET" enctype="multipart/form-data" accept-charset="utf-8">
      <label>Paises</label>
      <!--<a href="borrar.php"> <input type="text" name="id" required="" placeholder=" campo a borrar "/></a>-->
      <input type="text" name="id" placeholder="id" />
      <input type="text" name="capitaln" placeholder="capital" />
      <input class="enviar" type="submit" text="Enviar" />
    </form>


    <?php
    $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
    $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');

    //   $capitaln =$_POST['capitaln'];
    
   
    $sql = "SELECT * FROM capital";
    $result = mysqli_query($link, $sql);
    if ($result) {
      if (mysqli_num_rows($result) > 0) {
        echo "<table border='1'>";
        echo "<tr>";
         echo "<th>id</th>";
        echo "<th>capitaln</th>";

        echo "</tr>";
        while ($row = mysqli_fetch_array($result)) {
          echo "<tr>";
           echo "<td>" . $row['id'] . "</td>";
          echo "<td>" . $row['capitaln'] . "</td>";
          echo "</tr>";
        }


        echo "</table>";
        // Free result set
        mysqli_free_result($result);
      } else {
        echo "No encontrado.";
      }
    } else {
      echo "ERROR:  $sql. " . mysqli_error($link);
    }
    ?>
    <?php
    //delete
    //Creamos la sentencia SQL y la ejecutamos


    $id = filter_input(INPUT_GET, 'id');
    //$capitaln = $_GET['capitaln']; 
    $capitaln = filter_input(INPUT_GET, 'capitaln');
    echo $capitaln;
    echo  $id;

    $query = "delete from capital where id = '$id' and capitaln='$capitaln'";
    $result2 = mysqli_query($link, $query);
    

    echo "<p>El registro ha sido eliminado con exito.$id </p>";


    ?>

  </div>
</body>

</html>
<!--Para enlazar copn los datos actuales
<h1><div align="center">Registro Borrado</div></h1>
<div align="center"><a href="mostrar.php">Visualizar el contenido de la base</a></div>
-->