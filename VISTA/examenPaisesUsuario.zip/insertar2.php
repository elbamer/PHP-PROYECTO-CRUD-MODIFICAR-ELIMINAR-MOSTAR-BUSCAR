<html>

<head>
  <meta charset="UTF-8">
  <title></title>
  <link rel="stylesheet" href="estilos.css" />
</head>

<body>
  <div class="formulario">Formulario alta paises </div>
  <!--	<form action="formu_Movil_submit" method="get" accept-charset="utf-8">-->
  <form action="insertar2.php" method="post" enctype="multipart/form-data">
    <fieldset>
      <legend class="h2">Introduce el pais a dar de alta</legend>
      <label></label>
      <input class="tama-formu" type="text" name="capitaln" placeholder=" capital " />

      <input class="enviar" type="submit" text="Enviar" />
    </fieldset>
  </form>
</body>

</html>
<?php
$link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
$db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');

// $capitaln=$_POST['capitaln'];
// $nombreUsuario = $_POST['capitaln'];
$capitaln = filter_input(INPUT_POST, 'capitaln');


$consulta = "INSERT INTO capital (capitaln) VALUES('$capitaln')";

echo "----------------" . $consulta . "--";

mysqli_query($link, $consulta) or die("<h3>Error al insertar en la tabla </h3>");
$sqli = "select * from capital where capitaln='$capitaln'";
$result = $link->query($sqli);
$row = $result->fetch_assoc();
//  $userId = $row["id"];

//echo " Eres el usuario ".$userId;
echo "!Gracias¡  Hemos recibido correctamente sus datos.\n";

/*$sql = "SELECT * FROM capital";
if ($result = mysqli_query($link, $sql)) {
  if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    echo "<tr>";
    echo "<th>id</th>";
    echo "<th>capital</th>";
    echo "<th>capital</th>";
   
    echo "</tr>";
    while ($row = mysqli_fetch_array($result)) {
      echo "<tr>";
      echo "<td>" . $row['id'] . "</td>";
      echo "<td>" . $row['capitaln'] . "</td>";

     
      echo "</tr>";
    }


    echo "</table>";
    // Free result set
    mysqli_free_result($result);
  } else {
    echo "No encontrado.";
  }
} else {
  echo "ERROR:  $sql. " . mysqli_error($link);
}


/*$result="SELECT  nombre FROM ciuada WHERE id ROUND.'*(SELECT COUNT (*)FROM usuarios)LIMIT 1")));
echo ' aleatorio$Sql';


$query=mysqli_query ("SELECT capitaln FROM capital");
if ($result = mysqli_query($link, $sql)) {
  if (mysqli_num_rows($result) > 0) {
    $ciudades=array();
}}

   while ($row = mysqli_fetch_array($query)) {
     $ciudades[]=$row['capitaln'];


   echo " " . $row['capitaln'] . "</td>";}


  //  }
  //  $RandRow=array_rand($ciudades,1);
?>*/
?>