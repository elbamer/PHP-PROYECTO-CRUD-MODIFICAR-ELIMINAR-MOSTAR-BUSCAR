<html>

<head>
  <meta charset="UTF-8">
  <title></title>
  <link rel="stylesheet" href="estilos.css" />
</head>

<body>
  <div class="borrar">
    <h2>Indica el pais a borrar</h2>

    <form action="eliminarUsu.php" method="GET" enctype="multipart/form-data" accept-charset="utf-8">
      <label>Paises</label>
      <!--<a href="borrar.php"> <input type="text" name="id" required="" placeholder=" campo a borrar "/></a>-->
      <input type="text" name="idUsu" placeholder="id" />
      <input type="text" name="nombreUsuario" placeholder="nombreUsuario" />
      <input type="text" name="idPais" placeholder="isPais" />
     


    <?php
    $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
    $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');

    //   $capitaln =$_POST['capitaln'];

    $sql = "SELECT * FROM usuario";
    $result = mysqli_query($link, $sql);
    if ($result) {
      if (mysqli_num_rows($result) > 0) {
        echo "<table border='1'>";
        echo "<tr>";
         echo "<th>Id</th>";
        echo "<th>nombreUsuario</th>";
         echo "<th>Pais</th>";

        echo "</tr>";
        while ($row = mysqli_fetch_array($result)) {
          echo "<tr>";
           echo "<td>" . $row['idUsu'] . "</td>";
          echo "<td>" . $row['nombreUsuario'] . "</td>";
            echo "<td>" . $row['idPais'] . "</td>";
          echo "</tr>";
        }


        echo "</table>";
        // Free result set
        mysqli_free_result($result);
      } else {
        echo "No encontrado.";
      }
    } else {
      echo "ERROR:  $sql. " . mysqli_error($link);
    }
    ?>
       <input class="enviar" type="submit" text="Enviar" />
    </form>
    <?php
    //delete
    //Creamos la sentencia SQL y la ejecutamos


    $idUsu = filter_input(INPUT_GET, 'idUsu');
    //$capitaln = $_GET['capitaln']; 
    $nombreUsuario= filter_input(INPUT_GET, 'nombreUsuario');
        $idPais= filter_input(INPUT_GET, 'idPais');

    echo $nombreUsuario;
    echo  $idUsu;

    $query = "delete from usuario where idUsu = '$idUsu' and nombreUsuario='$nombreUsuario'";
    
    $result2 = mysqli_query($link, $query);

    echo "<p>El registro ha sido eliminado con exito.$idUsu</p>";


    ?>

  </div>
</body>

</html>
<!--Para enlazar copn los datos actuales
<h1><div align="center">Registro Borrado</div></h1>
<div align="center"><a href="mostrar.php">Visualizar el contenido de la base</a></div>
-->