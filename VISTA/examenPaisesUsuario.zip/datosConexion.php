<?php
define("DB_USUARIO","elba");
define("DB_PASSWORD","liayan686");
define("DB_HOST","localhost");
define("DB_NOMBRE","ciudades")
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
?>

