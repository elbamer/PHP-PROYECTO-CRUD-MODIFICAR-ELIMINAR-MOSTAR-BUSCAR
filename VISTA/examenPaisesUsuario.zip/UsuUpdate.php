<html>

<head>
  <title>title</title>
  <link rel="stylesheet" href="estilos.css" />
</head>

<body>
  <div id="containerUpdate">
    <h2> Editando los datos de la Base de datos</h2>

    <form method="POST" action="UsuUpdate.php">
      <?php
      $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error(link));
      $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');

      $sql = "SELECT * FROM usuario";
      $result = mysqli_query($link, $sql);
      if ($result) {
        if (mysqli_num_rows($result) > 0) {
          echo "<table border='3'>";
          echo "<tr>";
          // echo "<th>id</th>";
          echo "<th>nombreUsuario</th>";
          echo "<th>id</th>";

          echo "</tr>";
          while ($row = mysqli_fetch_array($result)) {

            echo "<tr>";
            echo "<td hidden>".'<input name="idalu[]" value="'.$row['idUsu'].'"/>'."</td>";
            // echo "<td>" . $row[''] . "</td>";
            //  echo "<td hidden>".'<input name="arrayGlobal[]" value="'. $row['id'].'"/>'."<td>";

            echo "<td>" . '<input name="arrayId[' . $row['idUsu'] . ']" value="' . $row['idUsu'] . '"/>' . "</td>";
            echo "<td>" . '<input name="arrayNombre[' . $row['idUsu'] . ']"  value="' . $row['nombreUsuario'] . '"/>' . "</td>";
            // echo "<td>" . $row['capitaln'] . "</td>";
            // echo "<td>" . $row['id'] . "</td>";         echo "</tr>";
          }
        }
      }
      echo "</table>";
      //nuevo editar    

      
   ?>  <input type="submit" name="actualizar" value="ACTUALIZAR"></a>  
    
    </form>
    <?php
    // && !empty($_POST['idgpo']) && !empty($_POST['idalumno'])) {        
    $actualizar = filter_input(INPUT_POST, 'actualizar');
    if (isset($actualizar)) { // && !empty($_POST['id']) && !empty($_POST['capitaln'])) {
        
        foreach ($_POST['idalu'] as $ids) {

        $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
        $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');
        // $editId= mysqli_real_escape_string($_GET,['arrayId'][$ids]);
        //$editId = addslashes('arrayId'[$ids]);
        $editId=mysqli_real_escape_string($link, $_POST['arrayId'][$ids]);


//        $editNom = addslashes('arrayNombre'[$ids]);
        $editNom = mysqli_real_escape_string($link, $_POST['arrayNombre'][$ids]);
        //$sql = "SELECT * FROM capital WHERE id='$editId' && capitaln='$editNom";

        $actualizar = $link->query("UPDATE usuario SET nombreUsuario='$editNom' WHERE idUsu='$editId'");
        //echo "entra.$editNom.$editId";
//        if ($actualizar == true) {
//          echo "Se ha actualizado ";
//          // echo "entra.".$editNom.$editId; 
//          echo "funciona! <a href='mostrar1.php'> Clip aqui</a>";
//        } else {
//          echo "Vaya no funciona";
//        }   
      }
       header('location:mostrarUsuario.php');
      echo "funciona! Mira los datos actualizados  <a href='mostrarUsuario.php'> aqui</a>";
    }
    ?>
  </div>
</body>

</html>