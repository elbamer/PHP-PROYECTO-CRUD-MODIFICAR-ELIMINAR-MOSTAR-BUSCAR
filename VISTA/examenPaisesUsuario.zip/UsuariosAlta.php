<html>

<head>
  <meta charset="UTF-8">
  <title></title>
  <link rel="stylesheet" href="styles.css" />
</head>

<body>
  <div class="formulario">Formulario alta Usuarios </div>
  <!--	<form action="formu_Movil_submit" method="get" accept-charset="utf-8">-->
  <form action="UsuariosAlta.php" method="post" enctype="multipart/form-data">
    <fieldset>
      <legend class="h2">Datos requeridos</legend>
      <label></label>
      <input type="text" name="nombreUsuario" placeholder="nombre " required="" />
     <div class="option">
            <p>Elige el pais</p>

            <?php
            $link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
            $db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');
           $query= "SELECT * FROM capital";
           $result = mysqli_query($link, $query);
           if(isset($_POST['cogerNombre'])){
              
           $cogerNombre=($_POST['cogerNombre']);
           echo"Tu pais es  $cogerNombre";
           }
            ?>
            <?php
            // coge de la table capital
            $query = "SELECT * FROM capital";// hago la query
            $result = mysqli_query($link, $query);// meto en la variable result la conecion y la query
            echo "<select name='cogerNombre'>";
            while ($row = mysqli_fetch_array($result)) {//
                echo "<option value='" . $row["capitaln"] . "'>" . $row["capitaln"] . "</option>";
          // sacamos lo que tenemos en la bbdd 
                }
            echo "</select>";
            ?> 
        </div>
      
      <input class="enviar" type="submit" text="Enviar" />
    </fieldset>
  </form>
   <?php
$link = mysqli_connect("localhost", "elba", "liayan686") or die('No se puede conectar:' . mysqli_error());
$db = mysqli_select_db($link, "usuarios1") or die('No se pudo seleccionar la base de datos');


// $capitaln=$_POST['capitaln'];
// $nombreUsuario = $_POST['capitaln'];
 $cogerNombre=filter_input(INPUT_POST,'cogerNombre');
$nombreUsuario = filter_input(INPUT_POST, 'nombreUsuario');// meto en la variable lo que me pasa por post

echo "$cogerNombre";
$consulta = "INSERT INTO usuario (nombreUsuario,idPais) VALUES('$nombreUsuario','$cogerNombre')";

echo "----------------" . $consulta . "--";

mysqli_query($link, $consulta) or die("<h3>Error al insertar en la tabla </h3>");
$sqli = "select * from usuario where nombreUsuario='$nombreUsuario'";
$result = $link->query($sqli);
$row = $result->fetch_assoc();
//  $userId = $row["id"];

//echo " Eres el usuario ".$userId;
echo "!Gracias¡  Hemos recibido correctamente sus datos.\n";

?>

